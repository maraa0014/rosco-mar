import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";

const questions = {
  A: [
    { clue: "Empieza con A: Mamífero marino con colmillos largos.", answer: "Morsa", category: "Animales" },
    { clue: "Empieza con A: País donde se encuentra la Torre Eiffel.", answer: "Alemania", category: "Cultura general" },
    { clue: "Empieza con A: Película animada donde una niña cae en un mundo de maravillas.", answer: "Alicia en el País de las Maravillas", category: "Películas" },
  ],
  B: [
    { clue: "Empieza con B: Color que se asocia con la tristeza.", answer: "Blanco", category: "Cultura general" },
    { clue: "Empieza con B: Pez tropical muy colorido.", answer: "Betta", category: "Animales" },
    { clue: "Empieza con B: Saga de vampiros y hombres lobo.", answer: "Breaking Dawn", category: "Películas" },
  ],
  C: [
    { clue: "Empieza con C: País cuya capital es El Cairo.", answer: "Egipto", category: "Cultura general" },
    { clue: "Empieza con C: Ave que imita sonidos humanos.", answer: "Cotorra", category: "Animales" },
    { clue: "Empieza con C: Película sobre un payaso asesino de Stephen King.", answer: "It (Eso)", category: "Películas" },
  ],
  D: [
    { clue: "Empieza con D: Aparato que usamos para secarnos el cabello.", answer: "Secador", category: "Objetos" },
    { clue: "Empieza con D: Mamífero que vive en cuevas y se orienta por ecolocalización.", answer: "Delfín", category: "Animales" },
    { clue: "Empieza con D: Película de princesas ambientada bajo el mar.", answer: "La Sirenita", category: "Películas" },
  ],
  E: [
    { clue: "Empieza con E: Palabra que significa 'el arte de hablar bien en público'.", answer: "Elocuencia", category: "Palabras difíciles" },
    { clue: "Empieza con E: Animal que pone huevos y vuela.", answer: "Emú", category: "Animales" },
    { clue: "Empieza con E: Película donde un extraterrestre quiere volver a casa.", answer: "E.T.", category: "Películas" },
  ],
  F: [
    { clue: "Empieza con F: Nombre del perrito de la abuela.", answer: "Firulais", category: "Familiares" },
    { clue: "Empieza con F: Insecto que produce miel.", answer: "Fructosa", category: "Cultura general" },
    { clue: "Empieza con F: Película de Disney sobre una princesa guerrera china.", answer: "Mulan", category: "Películas" },
  ],
  Ñ: [
    { clue: "Contiene la Ñ: Elemento de baño que usamos para lavarnos.", answer: "Bañera", category: "Objetos" },
    { clue: "Contiene la Ñ: Herramienta usada para cortar madera.", answer: "Leñador", category: "Cultura general" },
    { clue: "Contiene la Ñ: Acción de sumergirse en el agua.", answer: "Baño", category: "Palabras difíciles" },
  ],
  P: [
    { clue: "Empieza con P: Clásico de Disney con un elefante volador.", answer: "Dumbo", category: "Películas" },
    { clue: "Empieza con P: Mamífero que se alimenta casi exclusivamente de bambú.", answer: "Panda", category: "Animales" },
    { clue: "Empieza con P: Objeto que usamos para escribir.", answer: "Pluma", category: "Objetos" },
  ]
};

const alphabet = Object.keys(questions);

export default function RoscoGame() {
  const [index, setIndex] = useState(0);
  const [usedLetters, setUsedLetters] = useState({});
  const [timeLeft, setTimeLeft] = useState(120);
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [gameStarted, setGameStarted] = useState(false);

  const currentLetter = alphabet[index];
  const availableQuestions = selectedCategory
    ? questions[currentLetter].filter(q => q.category === selectedCategory)
    : questions[currentLetter];

  const currentQuestion = availableQuestions.length > 0
    ? availableQuestions[Math.floor(Math.random() * availableQuestions.length)]
    : { clue: "Sin preguntas disponibles.", answer: "-", category: "" };

  useEffect(() => {
    if (!gameStarted) return;
    const timer = setInterval(() => {
      setTimeLeft((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, [gameStarted]);

  const handleAnswer = (status) => {
    setUsedLetters({
      ...usedLetters,
      [currentLetter]: status,
    });
  };

  const nextLetter = () => {
    const next = (index + 1) % alphabet.length;
    setIndex(next);
  };

  const getLetterColor = (letter) => {
    if (letter === currentLetter) return "bg-yellow-400 text-black";
    if (usedLetters[letter] === "correct") return "bg-green-500 text-white";
    if (usedLetters[letter] === "incorrect") return "bg-red-500 text-white";
    return "bg-gray-200 text-black";
  };

  if (!gameStarted) {
    const categories = Array.from(new Set(
      Object.values(questions).flat().map(q => q.category)
    ));

    return (
      <div className="flex flex-col items-center gap-4 p-4">
        <div className="text-2xl font-bold">Seleccioná una categoría:</div>
        <div className="flex flex-wrap gap-2">
          {categories.map((cat) => (
            <Button key={cat} onClick={() => { setSelectedCategory(cat); setGameStarted(true); }}>
              {cat}
            </Button>
          ))}
          <Button onClick={() => { setSelectedCategory(null); setGameStarted(true); }}>
            Todas las categorías
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center gap-4 p-4">
      <div className="relative w-80 h-80 flex items-center justify-center">
        {alphabet.map((letter, i) => {
          const angle = (360 / alphabet.length) * i;
          const x = 36 + 32 * Math.cos((angle * Math.PI) / 180);
          const y = 36 + 32 * Math.sin((angle * Math.PI) / 180);
          return (
            <div
              key={letter}
              className={`absolute w-8 h-8 flex items-center justify-center rounded-full text-sm font-bold ${getLetterColor(letter)}`}
              style={{ left: `${x}%`, top: `${y}%`, transform: "translate(-50%, -50%)" }}
            >
              {letter}
            </div>
          );
        })}
      </div>

      <div className="text-2xl font-bold">Letra: {currentLetter}</div>
      <div className="text-lg text-center max-w-xl">{currentQuestion.clue}</div>
      <div className="text-blue-600 font-semibold">
        Respuesta: {currentQuestion.answer} ({currentQuestion.category})
      </div>
      <div className="flex gap-4 mt-2">
        <Button onClick={() => handleAnswer("correct")}>✅ Correcta</Button>
        <Button onClick={() => handleAnswer("incorrect")}>❌ Incorrecta</Button>
        <Button onClick={nextLetter}>⏭ Pasar</Button>
      </div>
      <div className="mt-6 text-lg font-mono">⏱ Tiempo restante: {timeLeft}s</div>
    </div>
  );
}
